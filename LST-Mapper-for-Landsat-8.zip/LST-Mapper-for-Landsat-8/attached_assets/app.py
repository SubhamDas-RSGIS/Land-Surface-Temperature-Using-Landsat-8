import os
import numpy as np
import rasterio
import re
import matplotlib.pyplot as plt
from flask import Flask, request, render_template, send_file
from werkzeug.utils import secure_filename

# Initialize Flask app
app = Flask(__name__)

# Define Upload & Result Folders
UPLOAD_FOLDER = 'uploads'
RESULT_FOLDER = 'results'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['RESULT_FOLDER'] = RESULT_FOLDER

# Ensure Directories Exist
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(RESULT_FOLDER, exist_ok=True)

# Function to Read Metadata from MTL File
def read_mtl_file(mtl_path):
    mtl_data = {}
    with open(mtl_path, 'r') as file:
        for line in file:
            match = re.match(r'(\S+)\s=\s(\S+)', line.strip())
            if match:
                key, value = match.groups()
                mtl_data[key] = value.strip('"')

    return {
        "ML": float(mtl_data.get("RADIANCE_MULT_BAND_10", 0)),
        "AL": float(mtl_data.get("RADIANCE_ADD_BAND_10", 0)),
        "K1": float(mtl_data.get("K1_CONSTANT_BAND_10", 0)),
        "K2": float(mtl_data.get("K2_CONSTANT_BAND_10", 0))
    }

# Function to Compute NDVI
def ndvi(nir, red):
    nir = nir.astype(np.float32)
    red = red.astype(np.float32)
    return (nir - red) / (nir + red + 1e-10)

# Function to Compute Land Surface Emissivity (LSE)
def land_surface_emissivity(ndvi_array):
    return 0.004 * ndvi_array + 0.986

# Function to Compute Land Surface Temperature (LST)
def land_surface_temperature(BT, E):
    wavelength = 10.8  # for Landsat 8 Band 10
    c2 = 14388
    return BT / (1 + (wavelength * BT / c2) * np.log(E))

# Function to Process Landsat Images for LST
def process_landsat(thermal_path, nir_path, red_path, mtl_path):
    params = read_mtl_file(mtl_path)

    with rasterio.open(thermal_path) as src:
        Qcal = src.read(1)
        profile = src.profile

    with rasterio.open(nir_path) as src:
        nir = src.read(1)

    with rasterio.open(red_path) as src:
        red = src.read(1)

    # Compute NDVI
    ndvi_array = ndvi(nir, red)

    # Compute Emissivity
    E = land_surface_emissivity(ndvi_array)

    # Compute Brightness Temperature
    LA = params["ML"] * Qcal + params["AL"]
    BT = (params["K2"] / np.log((params["K1"] / LA) + 1)) - 273.15

    # Compute LST
    LST = land_surface_temperature(BT, E)

    # Save LST Output as GeoTIFF
    output_path = os.path.join(app.config['RESULT_FOLDER'], "LST_result.tif")
    profile.update(dtype=rasterio.float32, count=1)

    with rasterio.open(output_path, 'w', **profile) as dst:
        dst.write(LST.astype(rasterio.float32), 1)

    return output_path

# ✅ Route: Home Page (Upload Form)
@app.route("/", methods=["GET", "POST"])
def upload_file():
    if request.method == "POST":
        thermal = request.files["thermal"]
        nir = request.files["nir"]
        red = request.files["red"]
        mtl = request.files["mtl"]

        if not all([thermal, nir, red, mtl]):
            return "Please upload all required files.", 400

        thermal_path = os.path.join(app.config["UPLOAD_FOLDER"], secure_filename(thermal.filename))
        nir_path = os.path.join(app.config["UPLOAD_FOLDER"], secure_filename(nir.filename))
        red_path = os.path.join(app.config["UPLOAD_FOLDER"], secure_filename(red.filename))
        mtl_path = os.path.join(app.config["UPLOAD_FOLDER"], secure_filename(mtl.filename))

        thermal.save(thermal_path)
        nir.save(nir_path)
        red.save(red_path)
        mtl.save(mtl_path)

        result_path = process_landsat(thermal_path, nir_path, red_path, mtl_path)

        return render_template("result.html", result_url=result_path)

    return render_template("index.html")

# ✅ Route: Download Processed LST File
@app.route("/download")
def download_result():
    result_path = os.path.join(app.config['RESULT_FOLDER'], "LST_result.tif")
    return send_file(result_path, as_attachment=True)

@app.route("/")  # Home Page
def home():
    return render_template("index.html")


@app.route("/developer")  # Developer Page
def developer():
    return render_template("developer.html")

# Run Flask App
if __name__ == "__main__":
    app.run(debug=True)
