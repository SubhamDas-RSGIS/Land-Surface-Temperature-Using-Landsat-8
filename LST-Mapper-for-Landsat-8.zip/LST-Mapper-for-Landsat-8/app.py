import os
import numpy as np
import rasterio
import re
import matplotlib.pyplot as plt
from flask import Flask, request, render_template, send_file, flash, redirect, url_for
from werkzeug.utils import secure_filename

# Initialize Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "default-secret-key")

# Define Upload & Result Folders
UPLOAD_FOLDER = 'uploads'
RESULT_FOLDER = 'results'
ALLOWED_EXTENSIONS = {'tif', 'txt'}

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['RESULT_FOLDER'] = RESULT_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size

# Ensure Directories Exist
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(RESULT_FOLDER, exist_ok=True)

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def read_mtl_file(mtl_path):
    try:
        mtl_data = {}
        with open(mtl_path, 'r') as file:
            for line in file:
                match = re.match(r'(\S+)\s=\s(\S+)', line.strip())
                if match:
                    key, value = match.groups()
                    mtl_data[key] = value.strip('"')

        required_keys = ["RADIANCE_MULT_BAND_10", "RADIANCE_ADD_BAND_10", 
                        "K1_CONSTANT_BAND_10", "K2_CONSTANT_BAND_10"]

        for key in required_keys:
            if key not in mtl_data:
                raise ValueError(f"Required key {key} not found in MTL file")

        return {
            "ML": float(mtl_data["RADIANCE_MULT_BAND_10"]),
            "AL": float(mtl_data["RADIANCE_ADD_BAND_10"]),
            "K1": float(mtl_data["K1_CONSTANT_BAND_10"]),
            "K2": float(mtl_data["K2_CONSTANT_BAND_10"])
        }
    except Exception as e:
        raise ValueError(f"Error processing MTL file: {str(e)}")

def ndvi(nir, red):
    nir = nir.astype(np.float32)
    red = red.astype(np.float32)
    return (nir - red) / (nir + red + 1e-10)

def land_surface_emissivity(ndvi_array):
    return 0.004 * ndvi_array + 0.986

def land_surface_temperature(BT, E):
    wavelength = 10.8  # for Landsat 8 Band 10
    c2 = 14388
    return BT / (1 + (wavelength * BT / c2) * np.log(E))

def process_landsat(thermal_path, nir_path, red_path, mtl_path):
    try:
        params = read_mtl_file(mtl_path)

        with rasterio.open(thermal_path) as src:
            Qcal = src.read(1)
            profile = src.profile

        with rasterio.open(nir_path) as src:
            nir = src.read(1)

        with rasterio.open(red_path) as src:
            red = src.read(1)

        ndvi_array = ndvi(nir, red)
        E = land_surface_emissivity(ndvi_array)
        LA = params["ML"] * Qcal + params["AL"]
        BT = (params["K2"] / np.log((params["K1"] / LA) + 1)) - 273.15
        LST = land_surface_temperature(BT, E)

        output_path = os.path.join(app.config['RESULT_FOLDER'], "LST_result.tif")
        profile.update(dtype=rasterio.float32, count=1)

        with rasterio.open(output_path, 'w', **profile) as dst:
            dst.write(LST.astype(rasterio.float32), 1)

        # Generate preview image
        plt.figure(figsize=(10, 8))
        plt.imshow(LST, cmap='RdYlBu_r')
        plt.colorbar(label='Temperature (°C)')
        plt.title('Land Surface Temperature')
        preview_path = os.path.join(app.config['RESULT_FOLDER'], "preview.png")
        plt.savefig(preview_path)
        plt.close()

        return output_path, preview_path
    except Exception as e:
        raise RuntimeError(f"Error processing Landsat data: {str(e)}")

@app.route("/")
def index():
    return redirect(url_for('upload_file'))

@app.route("/lst-upload", methods=["GET", "POST"])
def upload_file():
    if request.method == "POST":
        try:
            if not all(key in request.files for key in ['thermal', 'nir', 'red', 'mtl']):
                flash("Please upload all required files.", "error")
                return redirect(request.url)

            files = {
                'thermal': request.files['thermal'],
                'nir': request.files['nir'],
                'red': request.files['red'],
                'mtl': request.files['mtl']
            }

            for key, file in files.items():
                if not allowed_file(file.filename):
                    flash(f"Invalid file format for {key}.", "error")
                    return redirect(request.url)

            paths = {}
            for key, file in files.items():
                filename = secure_filename(file.filename)
                filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                file.save(filepath)
                paths[key] = filepath

            result_path, preview_path = process_landsat(
                paths['thermal'], paths['nir'], paths['red'], paths['mtl']
            )

            return render_template("result.html", 
                                   result_url=result_path,
                                   preview_url=preview_path)

        except Exception as e:
            flash(str(e), "error")
            return redirect(request.url)

    return render_template("index.html")

@app.route("/lst-download")
def download_result():
    try:
        result_path = os.path.join(app.config['RESULT_FOLDER'], "LST_result.tif")
        return send_file(result_path, as_attachment=True)
    except Exception as e:
        flash("Error downloading result file.", "error")
        return redirect(url_for('upload_file'))

@app.route("/about-developer")
def developer():
    return render_template("developer.html")

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)